package pt.ulusofona.aed.deisimdb.dataClasses;

public class Result {
    private boolean sucesso;
    private String error;
    private String resultado;



    public Result() {}



    public void comandoInvalido() {
        sucesso = false;
        error = "Comando invalido";
        resultado = null;
    }

    public void comandoCorreto(String resultado) {
        sucesso = true;
        error = null;
        this.resultado = resultado;
    }


    public boolean getSucesso() {
        return sucesso;
    }

    public String getError() {
        return error;
    }

    public String getResultado() {
        return resultado;
    }



    @Override
    public String toString() {
        return "Sucesso: " + sucesso + "\nError: " + error + "\nResultado: " + resultado;
    }
}
