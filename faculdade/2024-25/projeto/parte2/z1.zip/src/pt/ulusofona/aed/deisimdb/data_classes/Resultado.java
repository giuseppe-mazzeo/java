package pt.ulusofona.aed.deisimdb.data_classes;

public class Resultado {
    private boolean sucesso;
    private String error;
    private String resultado;



    public Resultado() {}



    public void comandoInvalido() {
        sucesso = false;
        error = "Comando invalido";
        resultado = null;
    }

    public void comandoCorreto(String resultado) {
        sucesso = true;
        error = null;
        this.resultado = resultado;
    }
}
