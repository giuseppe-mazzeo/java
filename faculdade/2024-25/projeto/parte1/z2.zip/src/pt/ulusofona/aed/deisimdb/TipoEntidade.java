package pt.ulusofona.aed.deisimdb;

public enum TipoEntidade {
    ATOR,
    REALIZADOR,
    GENERO_CINEMATROGRAFICO,
    FILME,
    INPUT_INVALIDO
}
