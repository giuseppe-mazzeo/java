package pt.ulusofona.aed;

public class Pessoa {
    String nome;
    String apelido;
    int nrBi;
    String paisMorada;

    public Pessoa() {}

    @Override
    public String toString() {
        return nome + " " + apelido + ", nrBI: " + nrBi + ", pais: " + paisMorada;
    }
}
