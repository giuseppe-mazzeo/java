package pt.ulusofona.aed;

public class Main {
    /*
    static _______ f01(_______, ________) {

    }

    /*
    static _______ f02(_______) {

    }

    static _______ f03(_______) {

    }

     */

    static String[] nomesDasFuncoes() {
        return new String[] {
                "",
                "",
                ""
        };
    }




    public static void main(String[] args) {

    }
}
