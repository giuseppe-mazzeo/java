package pt.ulusofona.aed;

public class Main {
    static int f01(int[] numeros, int inicio) {
        return 0;
    }

    static boolean f02(char[] letra) {
        return false;
    }

    static int f03(int[] numeros) {
        return 0;
    }

    static String[] nomesDasFuncoes() {
        return new String[] {
                "",
                "",
                "multiplicarArray"
        };
    }




    public static void main(String[] args) {

    }
}
