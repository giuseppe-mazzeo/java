package pt.ulusofona.aed;

import java.util.Arrays;


public class Main {
    static Pessoa[] gerarAmigosDosAnimais() {
        Animal cao1 = new Animal("Bimbo", "Cão", 12345);
        Animal cavalo = new Animal("Planeta", "Cavalo", 33333);
        Animal cao2 = new Animal("Alfaiate", "Cão", 55555);
        Animal papagaio = new Animal("Carapau", "Papagaio", 44155);

        Pessoa victor = new Pessoa("Victor", "Valente", 12388193, new Animal[] {cao1});
        Pessoa rodrigo = new Pessoa("Rodrigo", "Correia", 12377341, new Animal[] {cavalo, cao2});
        Pessoa joao = new Pessoa("João", "Batalha", 12300545, new Animal[] {papagaio});

        return new Pessoa[] {victor, rodrigo, joao};
    }



    static boolean f02(Pessoa pessoa) {
        if (pessoa.animais == null) {
            return false;
        }

        for (Animal animal : pessoa.animais) {
            if (animal != null) {
                return true;
            }
        }

        return false;
    }



    static boolean f03(Pessoa pessoa) {
        if (pessoa.animais == null) {
            return false;
        }

        for (Animal animal : pessoa.animais) {
            if (animal.especie.equals("Cão")) {
                return true;
            }
        }

        return false;
    }



    static boolean f04(Pessoa pessoa, String especie) {

        return false;
    }



    static int f05(Pessoa pessoa, String especie) {
return 0;
    }



    static Pessoa f06(Pessoa pessoaA, Pessoa pessoaB) {
return null;
    }



    //Função sem o uso do ArrayList<Animal>
    static Animal[] f07(Pessoa[] pessoas) {


        return null;
    }



    static String[] nomesDasFuncoes() {
        return new String[] {
                "temAnimais",
                "temCaes",
                "temAnimalEspecifico",
                "quantidadeAnimalEspecifico",
                "temMaisAnimais",
                "devolveAnimais"
        };
    }



    public static void main(String[] args) {
        Animal cao1 = new Animal("Bimbo", "Cão", 12345);
        Animal cavalo = new Animal("Planeta", "Cavalo", 33333);
        Animal cao2 = new Animal("Alfaiate", "Cão", 55555);
        Animal papagaio = new Animal("Carapau", "Papagaio", 44155);
        Animal fantasma = new Animal();

        Pessoa victor = new Pessoa("Victor", "Valente", 12388193, new Animal[] {});
        Pessoa rodrigo = new Pessoa("Rodrigo", "Correia", 12377341, new Animal[] {null, cao2, null, cao1});
        System.out.println(rodrigo.toString());

        //System.out.println(f06(victor, rodrigo));
        //System.out.println(Arrays.toString(f07(new Pessoa[] {victor, rodrigo})));
    }
}
