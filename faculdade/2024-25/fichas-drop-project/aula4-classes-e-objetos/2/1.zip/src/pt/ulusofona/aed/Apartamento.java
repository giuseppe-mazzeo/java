package pt.ulusofona.aed;

public class Apartamento {
    String nome_da_rua;
    int nr_porta;
    String localidade;
    String pais;


    public Apartamento(String nome_da_rua, int nr_porta, String localidade, String pais) {
        this.nome_da_rua = nome_da_rua;
        this.nr_porta = nr_porta;
        this.localidade = localidade;
        this.pais = pais;
    }


    @Override
    public String toString() {
        return nome_da_rua + " " + nr_porta + ", " + localidade + ", " + pais;
    }
}
