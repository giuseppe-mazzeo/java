package pt.ulusofona.aed;

public class Pessoa {
    String nome;
    String apelido;
    int nrBI;
    String paisMorada;

    public Pessoa(String nome, String apelido, int nrBI, String paisMorada) {
        this.nome = nome;
        this.apelido = apelido;
        this.nrBI = nrBI;
        this.paisMorada = paisMorada;
    }
}
