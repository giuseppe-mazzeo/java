public class Main {
    public static void main(String[] args) {
        System.out.println(sequenciaAlgarismos("12345",0));
    }

    static String obtemSubStringEmMaiuscula(String s, int inicio, int fim) {
        return "";
    }

    static int aednacci(int n) {
        if (n == 0 || n == 1) {
            return n;
        }

        return aednacci(n - 1) + aednacci(n -2) + n;
    }

    static boolean sequenciaAlgarismos(String s, int pos) {
        if (s == null || s.equals("") || pos > s.length()) {
            return false;
        }

        if (s.length() == 1) {
            return Character.isDigit(s.charAt(0));
        }

        if (s.length() == pos) {
            return Character.isDigit(s.charAt(pos-1));
        }

        if (!Character.isDigit(s.charAt(pos))) {
            return false;
        } else {
            return sequenciaAlgarismos(s, pos + 1);
        }
    }
}
